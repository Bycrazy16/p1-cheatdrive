#ifndef CUSTOM
#define CUSTOM

int calc();

#endif
